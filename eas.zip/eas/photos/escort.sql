-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2022 at 06:38 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `escort`
--

-- --------------------------------------------------------

--
-- Table structure for table `escorts`
--

CREATE TABLE `escorts` (
  `id` int(123) NOT NULL,
  `name` varchar(123) NOT NULL,
  `location` varchar(123) NOT NULL,
  `age` int(123) NOT NULL,
  `type` varchar(132) NOT NULL,
  `photo` int(123) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `google_users`
--

CREATE TABLE `google_users` (
  `id` int(123) NOT NULL,
  `iid` varchar(123) NOT NULL,
  `name` varchar(123) NOT NULL,
  `email` varchar(123) NOT NULL,
  `picture` varchar(123) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `google_users`
--

INSERT INTO `google_users` (`id`, `iid`, `name`, `email`, `picture`) VALUES
(1, '116353359280499235070', 'Nash Tunic', 'nashtunic@gmail.com', 'https://lh3.googleusercontent.com/a-/AFdZucq53RWyYbl5I_lAP2LH-1fRUMfy9Be17z0XAvSn=s96-c'),
(2, '105427738390413573156', 'Francis Kitema', 'fkdevelopers254@gmail.com', 'https://lh3.googleusercontent.com/a/AItbvmknd8V9vWTsA7mbNiWVqbA3VpfdA9RlcIMQ3D9d=s96-c'),
(3, '101674117167663528060', 'RMORE Collections', 'rmorecollections@gmail.com', 'https://lh3.googleusercontent.com/a/AItbvmlx-WeN1R56CpFm8sSU3MxQdOyXimOx-H5ryLlf=s96-c');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `escorts`
--
ALTER TABLE `escorts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `google_users`
--
ALTER TABLE `google_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `escorts`
--
ALTER TABLE `escorts`
  MODIFY `id` int(123) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `google_users`
--
ALTER TABLE `google_users`
  MODIFY `id` int(123) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
