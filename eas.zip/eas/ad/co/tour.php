  <!DOCTYPE html>
<html lang="en">
     
    <?php include('header.php');?>

  <body>
   <?php include('topnav.php');?>

       <?php include('destinationslider.php');?>

      <?php include('destination.php');?>
        <?php include('packages.php');?> 

       <?php include('footer.php');?>




  <!-- loader -->

<?php include('loader.php');?>
<?php include('scripts.php');?>


  </body>
</html>
