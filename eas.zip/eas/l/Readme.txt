Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/like-unlike-using-ajax-jquery-php/

Instructions -

1. Import attached posts.sql and like_unlike.sql file in your database.
2. Update config.php file.

